function exportarPDFInventario() {
    window.location.href = "/inventario/export/pdf";
}

function exportarExcelInventario() {
    window.location.href = "/inventario/export/excel";
}
