document.addEventListener("DOMContentLoaded", () => {

    const API_BASE = "/api/dashboard";

    const kpiIngresos = document.getElementById("kpiIngresos");
    const kpiPacientes = document.getElementById("kpiPacientes");
    const kpiPromedio = document.getElementById("kpiPromedioExamenes");

    const lblIng = document.getElementById("kpiPeriodoIngresos");
    const lblPac = document.getElementById("kpiPeriodoPacientes");
    const lblProm = document.getElementById("kpiPeriodoPromedio");

    const filtroDesde = document.getElementById("filtroDesde");
    const filtroHasta = document.getElementById("filtroHasta");
    const filtroPeriodo = document.getElementById("filtroPeriodo");
    const filtroArea = document.getElementById("filtroArea");
    const btnAplicar = document.getElementById("btnAplicarFiltros");

    const hoy = new Date();
    const yyyy = hoy.getFullYear();
    const mm = String(hoy.getMonth() + 1).padStart(2, '0');
    const dd = String(hoy.getDate()).padStart(2, '0');
    const hoyStr = `${yyyy}-${mm}-${dd}`;

    filtroDesde.value = hoyStr;
    filtroHasta.value = hoyStr;
    filtroPeriodo.value = "DIA";

    let topExamsChart = null;

    function formatoCRC(monto) {
        return monto.toLocaleString('es-CR', {
            style: 'currency',
            currency: 'CRC',
            minimumFractionDigits: 2
        });
    }

    function getPeriodoLabel() {
        switch (filtroPeriodo.value) {
            case "DIA":
                return "| Hoy";
            case "SEMANA":
                return "| Esta semana";
            case "MES":
                return "| Este mes";
            default:
                return "| Personalizado";
        }
    }

    async function cargarAreas() {
        try {
            const resp = await fetch(`${API_BASE}/areas`);
            if (!resp.ok) {
                console.error("No se pudieron cargar las áreas");
                return;
            }

            const areas = await resp.json();
            // Limpiar el select
            filtroArea.innerHTML = "";

            // Opción "Todas las áreas"
            const optTodas = document.createElement("option");
            optTodas.value = "";
            optTodas.textContent = "Todas las áreas";
            filtroArea.appendChild(optTodas);

            // Agregar las áreas que llegan del backend, sin repetidos
            areas.forEach((a) => {
                const opt = document.createElement("option");
                opt.value = a;                     // valor tal cual lo maneja el backend
                opt.textContent = capitalizar(a);  // para mostrar bonito
                filtroArea.appendChild(opt);
            });
        } catch (e) {
            console.error("Error cargando áreas:", e);
        }
    }

    async function cargarResumen() {
        const params = new URLSearchParams();

        if (filtroPeriodo.value) {
            params.append("periodo", filtroPeriodo.value);
        } else {
            if (filtroDesde.value)
                params.append("desde", filtroDesde.value);
            if (filtroHasta.value)
                params.append("hasta", filtroHasta.value);
        }

        const resp = await fetch(`${API_BASE}/resumen?` + params.toString());
        if (!resp.ok) {
            console.error("Error cargando resumen");
            return;
        }
        const data = await resp.json();

        const ingresos = Number(data.ingresosTotales ?? 0);
        const pacientes = Number(data.pacientesAtendidos ?? 0);
        const promedio = Number(data.promedioExamenesPorPaciente ?? 0);

        kpiIngresos.textContent = formatoCRC(ingresos);
        kpiPacientes.textContent = pacientes.toString();
        kpiPromedio.textContent = promedio.toFixed(2);

        const label = getPeriodoLabel();
        lblIng.textContent = " " + label;
        lblPac.textContent = " " + label;
        lblProm.textContent = " " + label;
    }

    async function cargarTopExamenes() {
        const params = new URLSearchParams();
        params.append("desde", filtroDesde.value);
        params.append("hasta", filtroHasta.value);
        if (filtroArea.value) {
            params.append("area", filtroArea.value);
        }
        params.append("limite", "10");

        const resp = await fetch(`${API_BASE}/top-examenes?` + params.toString());
        if (!resp.ok) {
            console.error("Error cargando top exámenes");
            return;
        }
        const data = await resp.json();

        const nombres = data.map(d => d.nombreExamen);
        const cantidades = data.map(d => d.cantidad);

        if (!topExamsChart) {
            topExamsChart = new ApexCharts(document.querySelector("#topExamsChart"), {
                series: [{
                        name: "Cantidad de solicitudes",
                        data: cantidades
                    }],
                chart: {
                    type: 'bar',
                    height: 350,
                    toolbar: {show: false}
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        columnWidth: '60%'
                    }
                },
                dataLabels: {enabled: false},
                xaxis: {
                    categories: nombres,
                    labels: {rotate: -45}
                },
                yaxis: {
                    title: {text: 'Número de solicitudes'}
                }
            });
            topExamsChart.render();
        } else {
            topExamsChart.updateOptions({
                xaxis: {categories: nombres},
                series: [{name: "Cantidad de solicitudes", data: cantidades}]
            });
        }
    }

    async function refrescarDashboard() {
        await Promise.all([
            cargarResumen(),
            cargarTopExamenes()
        ]);
    }

    btnAplicar.addEventListener("click", () => {
        if (filtroPeriodo.value === "DIA") {
            filtroDesde.value = hoyStr;
            filtroHasta.value = hoyStr;
        } else if (filtroPeriodo.value === "SEMANA") {
            const date = new Date();
            const day = date.getDay(); // 0 domingo
            const diff = date.getDate() - day + (day === 0 ? -6 : 1); // lunes
            const lunes = new Date(date.setDate(diff));
            const yyyyL = lunes.getFullYear();
            const mmL = String(lunes.getMonth() + 1).padStart(2, '0');
            const ddL = String(lunes.getDate()).padStart(2, '0');
            filtroDesde.value = `${yyyyL}-${mmL}-${ddL}`;
            filtroHasta.value = hoyStr;
        } else if (filtroPeriodo.value === "MES") {
            const primeroMes = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
            const yyyyP = primeroMes.getFullYear();
            const mmP = String(primeroMes.getMonth() + 1).padStart(2, '0');
            const ddP = String(primeroMes.getDate()).padStart(2, '0');
            filtroDesde.value = `${yyyyP}-${mmP}-${ddP}`;
            filtroHasta.value = hoyStr;
        }
        refrescarDashboard();
    });

    filtroArea.addEventListener("change", refrescarDashboard);

    // Carga inicial
    async function init() {
        await cargarAreas();
        await refrescarDashboard();
    }

    init();
});