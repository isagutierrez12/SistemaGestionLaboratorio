/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.laboratorio.controller;
import com.laboratorio.model.Cita;
import com.laboratorio.model.CitaCalendarioDTO;
import com.laboratorio.model.DetallePaquete;
import com.laboratorio.model.Examen;
import com.laboratorio.model.Paciente;
import com.laboratorio.model.Paquete;
import com.laboratorio.model.Solicitud;
import com.laboratorio.model.SolicitudDetalle;
import com.laboratorio.service.CitaService;
import com.laboratorio.service.ExamenService;
import com.laboratorio.service.InventarioService;
import com.laboratorio.service.PacienteService;
import com.laboratorio.service.PaqueteService;
import com.laboratorio.service.SolicitudService;
import com.laboratorio.service.UsuarioService;
import com.laboratorio.services.impl.EmailServiceImpl;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 *
 * @author soportetecnico
 */
@Controller
@RequestMapping("/cita")

public class CitaController {
    
     private final CitaService citaService;
    private final SolicitudService solicitudService;
    private final UsuarioService usuarioService;
    private final ExamenService examenService;
    private final PacienteService pacienteService;
    private final PaqueteService paqueteService;
    private EmailServiceImpl emailServiceImpl; 
    private final InventarioService inventarioService;
            
    @Autowired
    public CitaController(
            CitaService citaService,
            SolicitudService solicitudService,
            UsuarioService usuarioService,
            ExamenService examenService,
            PacienteService pacienteService,
            PaqueteService paqueteService,
            EmailServiceImpl emailServiceImpl, 
            InventarioService inventarioService
            ) {
        this.citaService = citaService;
        this.solicitudService = solicitudService;
        this.usuarioService = usuarioService;
        this.examenService = examenService;
        this.pacienteService = pacienteService;
        this.paqueteService = paqueteService;
        this.emailServiceImpl = emailServiceImpl;
        this.inventarioService = inventarioService;
    }

    // Listado de citas
    @GetMapping("/citas")
    public String listarCitas(Model model) {
       List<CitaCalendarioDTO> citasDTO = citaService.getAll().stream()
    .map(c -> {
        var solicitud = c.getSolicitud();

        // Extraer nombres de exámenes y paquetes
        List<String> examenes = solicitud.getDetalles().stream()
            .filter(d -> d.getExamen() != null)
            .map(d -> d.getExamen().getNombre())
            .toList();

        List<String> paquetes = solicitud.getDetalles().stream()
            .filter(d -> d.getPaquete() != null)
            .map(d -> d.getPaquete().getNombre())
            .toList();

        return new CitaCalendarioDTO(
            c.getIdCita(),
            solicitud.getPaciente().getNombre() + " " + solicitud.getPaciente().getPrimerApellido(),
            c.getFechaCita(),
            c.getEstado(),
            c.getNotas(),
            examenes,
            paquetes
        );
    })
    .toList();

    model.addAttribute("citas", citasDTO);
    return "cita/citas";
    }

    // Formulario para agregar una nueva cita
    @GetMapping("/agregar")
    public String agregarCita(Model model) {
        model.addAttribute("cita", new Cita());
        model.addAttribute("pacientes", pacienteService.getAll());
        model.addAttribute("examenesDisponibles", examenService.getAll());
        model.addAttribute("paquetesDisponibles", paqueteService.getAll());
        model.addAttribute("solicitudes", solicitudService.getAll());
        return "cita/agregar";
    }

    // Guardar cita
    @PostMapping("/guardar")
    public String guardarCita(
        @RequestParam("idPaciente") String idPaciente,
        @RequestParam("fechaCita") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaCita,
        @RequestParam(value = "notas", required = false) String notas,
        @RequestParam(value = "examenesSeleccionados", required = false) List<Long> examenesSeleccionados,
        @RequestParam(value = "paquetesSeleccionados", required = false) List<Long> paquetesSeleccionados,
        @AuthenticationPrincipal UserDetails userDetails,
        RedirectAttributes redirectAttrs) {

    try {
        // 1. Crear la solicitud
        Solicitud solicitud = new Solicitud();
        solicitud.setPaciente(pacienteService.get(idPaciente));
        solicitud.setUsuario(usuarioService.getUsuarioPorUsername(userDetails.getUsername()));
        solicitud.setFechaSolicitud(LocalDateTime.now());
        solicitud.setEstado("Agendada");

        double precioTotal = 0.0;

        // 2. Agregar exámenes individuales a la solicitud
        if (examenesSeleccionados != null && !examenesSeleccionados.isEmpty()) {
            List<Examen> examenes = examenService.findById(examenesSeleccionados);
            for (Examen examen : examenes) {
                SolicitudDetalle detalle = new SolicitudDetalle();
                detalle.setExamen(examen);
                solicitud.addDetalle(detalle);
                precioTotal += examen.getPrecio().doubleValue();
            }
        }

        // 3. Agregar paquetes (y sus exámenes) a la solicitud
      if (paquetesSeleccionados != null && !paquetesSeleccionados.isEmpty()) {
        for (Long idPaquete : paquetesSeleccionados) {
            Paquete paquete = paqueteService.getById(idPaquete); // ✅ Correcto
            if (paquete != null) {
                // Agregar los exámenes del paquete a la solicitud
                for (DetallePaquete dp : paquete.getDetalles()) {
                    Examen examenPaquete = dp.getExamen();
                    SolicitudDetalle detalle = new SolicitudDetalle();
                    detalle.setExamen(examenPaquete);
                    solicitud.addDetalle(detalle);
                    precioTotal += examenPaquete.getPrecio().doubleValue();
                }
            }
        }
    }

        // 4. Asignar precio total a la solicitud
        solicitud.setPrecioTotal(precioTotal);

        // 5. Crear la cita asociada
        Cita cita = new Cita();
        cita.setSolicitud(solicitud);
        cita.setUsuario(usuarioService.getUsuarioPorUsername(userDetails.getUsername()));
        cita.setFechaCita(fechaCita);
        cita.setNotas(notas);
        cita.setEstado("AGENDADA");

        // 6. Guardar solicitud y cita
        solicitudService.save(solicitud);
        citaService.save(cita);
        System.out.println(cita.getIdCita());
        inventarioService.ajustarInventarioPorCita(cita.getIdCita(), cita.getEstado());
        // 7. Enviar correo al paciente
        Paciente paciente = solicitud.getPaciente();

        String destinatario = paciente.getEmail();
        String asunto = "Confirmación de cita - Laboratorio Clínico";

        // Construir tabla HTML de exámenes
        StringBuilder examenesHtml = new StringBuilder();
        if (solicitud.getDetalles() != null && !solicitud.getDetalles().isEmpty()) {
            examenesHtml.append("""
                <table border="1" cellspacing="0" cellpadding="8" style="border-collapse: collapse; width: 100%;">
                    <thead style="background-color: #f2f2f2;">
                        <tr>
                            <th style="text-align:left;">Código</th>
                            <th style="text-align:left;">Nombre del Examen</th>
                            <th style="text-align:right;">Precio</th>
                        </tr>
                    </thead>
                    <tbody>
            """);

            for (SolicitudDetalle detalle : solicitud.getDetalles()) {
                Examen ex = detalle.getExamen();
                examenesHtml.append(String.format("""
                    <tr>
                        <td>%s</td>
                        <td>%s</td>
                        <td style="text-align:right;">₡%.2f</td>
                    </tr>
                """, ex.getCodigo(), ex.getNombre(), ex.getPrecio().doubleValue()));
            }

            examenesHtml.append("""
                    </tbody>
                </table>
            """);
        } else {
            examenesHtml.append("<p><i>No se registraron exámenes en esta cita.</i></p>");
        }

        // Formatear fecha de cita
        String fechaFormateada = cita.getFechaCita()
            .format(DateTimeFormatter.ofPattern("dd/MM/yyyy 'a las' HH:mm"));

        //  Construir contenido HTML del correo
        String contenido = """
        <html>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <h2>Estimado/a %s %s %s,</h2>
            <p>Su cita ha sido registrada correctamente en nuestro sistema.</p>

            <h3>📅 Detalles de la cita:</h3>
            <ul>
                <li><b>Fecha y hora:</b> %s</li>
                <li><b>Estado:</b> %s</li>
                <li><b>Notas:</b> %s</li>
                <li><b>Precio total:</b> ₡%.2f</li>
            </ul>

            <h3>🧪 Exámenes y paquetes incluidos:</h3>
            %s

            <br/>
            <p>Gracias por confiar en <b>Laboratorio Clínico</b>.</p>
            <hr/>
            <p style="font-size: 12px; color: #777;">Este es un mensaje automático, por favor no responder.</p>
        </body>
        </html>
        """.formatted(
                paciente.getNombre(),
                paciente.getPrimerApellido(),
                paciente.getSegundoApellido(),
                fechaFormateada,
                cita.getEstado(),
                (cita.getNotas() != null && !cita.getNotas().isEmpty()) ? cita.getNotas() : "Ninguna",
                solicitud.getPrecioTotal(),
                examenesHtml.toString()
        );

        //Enviar correo
        emailServiceImpl.enviarCorreoCita(destinatario, asunto, contenido);
            redirectAttrs.addFlashAttribute("mensaje", "Cita registrada correctamente.");
            redirectAttrs.addFlashAttribute("clase", "success");

    } catch (Exception e) {
        e.printStackTrace();
        redirectAttrs.addFlashAttribute("mensaje", "Error al registrar la cita.");
        redirectAttrs.addFlashAttribute("clase", "danger");
    }

    return "redirect:/cita/citas";

    }
    
    @GetMapping("/modificar/{id}")
    public String modificarCita(@PathVariable("id") Long idCita, Model model) {
    Cita cita = citaService.getById(idCita);
    if (cita == null) {
        return "redirect:/cita/citas";
    }

    // Obtener los IDs de exámenes y paquetes ya seleccionados
    List<Long> examenesSeleccionados = cita.getSolicitud().getDetalles().stream()
        .filter(d -> d.getExamen() != null)
        .map(d -> d.getExamen().getIdExamen())
        .toList();

    List<Long> paquetesSeleccionados = cita.getSolicitud().getDetalles().stream()
        .filter(d -> d.getPaquete() != null)
        .map(d -> d.getPaquete().getIdPaquete())
        .toList();

    model.addAttribute("cita", cita);
    model.addAttribute("examenesSeleccionados", examenesSeleccionados);
    model.addAttribute("paquetesSeleccionados", paquetesSeleccionados);
    model.addAttribute("examenesDisponibles", examenService.getAll());
    model.addAttribute("paquetesDisponibles", paqueteService.getAll());

    return "cita/modificar";
    } 
    
    
    @PostMapping("/actualizar")
    public String actualizarCita(
        @RequestParam("idCita") Long idCita,
        @RequestParam("fechaCita") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaCita,
        @RequestParam(value = "estado") String estado,
        @RequestParam(value = "notas", required = false) String notas,
        @RequestParam(value = "examenesSeleccionados", required = false) List<Long> examenesSeleccionados,
        @RequestParam(value = "paquetesSeleccionados", required = false) List<Long> paquetesSeleccionados,
        @AuthenticationPrincipal UserDetails userDetails,
        RedirectAttributes redirectAttrs) {

    try {
        // 1. Obtener la cita existente
        Cita cita = citaService.getById(idCita);
        if (cita == null) {
            redirectAttrs.addFlashAttribute("mensaje", "La cita no existe.");
            redirectAttrs.addFlashAttribute("clase", "danger");
            return "redirect:/cita/citas";
        }

        // 2. Obtener la solicitud asociada
        Solicitud solicitud = cita.getSolicitud();

        // 3. Limpiar detalles anteriores
        solicitud.getDetalles().clear();
        double precioTotal = 0.0;

        // 4. Agregar exámenes seleccionados
        if (examenesSeleccionados != null && !examenesSeleccionados.isEmpty()) {
            List<Examen> examenes = examenService.findById(examenesSeleccionados);
            for (Examen examen : examenes) {
                SolicitudDetalle detalle = new SolicitudDetalle();
                detalle.setExamen(examen);
                solicitud.addDetalle(detalle);
                precioTotal += examen.getPrecio().doubleValue();
            }
        }

        // 5. Agregar paquetes seleccionados
        if (paquetesSeleccionados != null && !paquetesSeleccionados.isEmpty()) {
            for (Long idPaquete : paquetesSeleccionados) {
                Paquete paquete = paqueteService.getById(idPaquete);
                if (paquete != null) {
                    for (DetallePaquete dp : paquete.getDetalles()) {
                        Examen examenPaquete = dp.getExamen();
                        SolicitudDetalle detalle = new SolicitudDetalle();
                        detalle.setExamen(examenPaquete);
                        solicitud.addDetalle(detalle);
                        precioTotal += examenPaquete.getPrecio().doubleValue();
                    }
                }
            }
        }

        // 6. Actualizar precio total
        solicitud.setPrecioTotal(precioTotal);

        // 7. Actualizar datos de la cita
        cita.setFechaCita(fechaCita);
        cita.setEstado(estado);
        cita.setNotas(notas);
        cita.setUsuario(usuarioService.getUsuarioPorUsername(userDetails.getUsername()));

        // 8. Guardar cambios
        solicitudService.save(solicitud);
        citaService.save(cita);

        inventarioService.ajustarInventarioPorCita(idCita, estado);
        // 9. Enviar correo al paciente
        Paciente paciente = solicitud.getPaciente();
        String destinatario = paciente.getEmail();
        String asunto = "Actualización de cita - Laboratorio Clínico";

        // Construir tabla HTML de exámenes
        StringBuilder examenesHtml = new StringBuilder();
        if (!solicitud.getDetalles().isEmpty()) {
            examenesHtml.append("""
                    <table border="1" cellspacing="0" cellpadding="8" style="border-collapse: collapse; width: 100%;">
                        <thead style="background-color: #f2f2f2;">
                            <tr>
                                <th style="text-align:left;">Código</th>
                                <th style="text-align:left;">Nombre del Examen</th>
                                <th style="text-align:right;">Precio</th>
                            </tr>
                        </thead>
                        <tbody>
                """);

            for (SolicitudDetalle detalle : solicitud.getDetalles()) {
                Examen ex = detalle.getExamen();
                examenesHtml.append(String.format("""
                        <tr>
                            <td>%s</td>
                            <td>%s</td>
                            <td style="text-align:right;">₡%.2f</td>
                        </tr>
                    """, ex.getCodigo(), ex.getNombre(), ex.getPrecio().doubleValue()));
            }
            examenesHtml.append("</tbody></table>");
        } else {
            examenesHtml.append("<p><i>No se registraron exámenes en esta cita.</i></p>");
        }

        // Formatear fecha
        String fechaFormateada = cita.getFechaCita()
                .format(DateTimeFormatter.ofPattern("dd/MM/yyyy 'a las' HH:mm"));

        // Contenido del correo
        String contenido = """
            <html>
            <body style="font-family: Arial, sans-serif; color: #333;">
                <h2>Estimado/a %s %s %s,</h2>
                <p>Su cita ha sido actualizada correctamente en nuestro sistema.</p>
                <h3>📅 Detalles de la cita:</h3>
                <ul>
                    <li><b>Fecha y hora:</b> %s</li>
                    <li><b>Estado:</b> %s</li>
                    <li><b>Notas:</b> %s</li>
                    <li><b>Precio total:</b> ₡%.2f</li>
                </ul>
                <h3>🧪 Exámenes y paquetes incluidos:</h3>
                %s
                <br/>
                <p>Gracias por confiar en <b>Laboratorio Clínico</b>.</p>
                <hr/>
                <p style="font-size: 12px; color: #777;">Este es un mensaje automático, por favor no responder.</p>
            </body>
            </html>
        """.formatted(
                paciente.getNombre(),
                paciente.getPrimerApellido(),
                paciente.getSegundoApellido(),
                fechaFormateada,
                cita.getEstado(),
                (cita.getNotas() != null && !cita.getNotas().isEmpty()) ? cita.getNotas() : "Ninguna",
                solicitud.getPrecioTotal(),
                examenesHtml.toString()
        );

        emailServiceImpl.enviarCorreoCita(destinatario, asunto, contenido);

        redirectAttrs.addFlashAttribute("mensaje", "Cita actualizada correctamente.");
        redirectAttrs.addFlashAttribute("clase", "success");

    } catch (Exception e) {
        e.printStackTrace();
        redirectAttrs.addFlashAttribute("mensaje", "Error al actualizar la cita.");
        redirectAttrs.addFlashAttribute("clase", "danger");
    }

    return "redirect:/cita/citas";
}

    // Buscar cita por solicitud o estado
    @GetMapping("/buscar")
    public String buscarCitas(@RequestParam("query") String query, Model model) {
        List<Cita> citas;
        if (query == null || query.trim().isEmpty()) {
            citas = citaService.getAll();
        } else {
            // Puedes luego implementar un método personalizado en el servicio/repo
            citas = citaService.getAll().stream()
                    .filter(c -> c.getEstado() != null && c.getEstado().toLowerCase().contains(query.toLowerCase()))
                    .toList();
        }
        model.addAttribute("citas", citas);
        model.addAttribute("query", query);
        return "cita/citas";
    }
}