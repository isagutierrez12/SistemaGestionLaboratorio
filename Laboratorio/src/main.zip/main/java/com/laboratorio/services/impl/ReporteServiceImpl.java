/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.laboratorio.services.impl;

import com.laboratorio.model.Reporte;
import com.laboratorio.model.SolicitudDetalle;
import com.laboratorio.repository.SolicitudDetalleRepository;
import com.laboratorio.service.ReporteService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReporteServiceImpl implements ReporteService {

    private final SolicitudDetalleRepository detalleRepository;

    public ReporteServiceImpl(SolicitudDetalleRepository detalleRepository) {
        this.detalleRepository = detalleRepository;
    }

    @Override
    public List<Reporte> generarReporte(
            LocalDate desde,
            LocalDate hasta,
            String area,
            String estado) {

        if (desde == null) {
            desde = LocalDate.now().minusMonths(1);
        }
        if (hasta == null) {
            hasta = LocalDate.now();
        }

        LocalDateTime desdeDateTime = desde.atStartOfDay();
        LocalDateTime hastaDateTime = hasta.atTime(23, 59, 59);

        List<SolicitudDetalle> detalles = detalleRepository.findAllConRelaciones();

        List<Reporte> resultado = new ArrayList<>();

        for (SolicitudDetalle d : detalles) {

            LocalDateTime fechaSolicitud = d.getSolicitud().getFechaSolicitud();
            if (fechaSolicitud == null) {
                continue;
            }
            if (fechaSolicitud.isBefore(desdeDateTime) || fechaSolicitud.isAfter(hastaDateTime)) {
                continue;
            }

            String areaNombre = null;
            if (d.getExamen() != null && d.getExamen().getArea() != null) {
                areaNombre = d.getExamen().getArea();
            }
            if (area != null && !area.isBlank()) {
                if (areaNombre == null || !areaNombre.equalsIgnoreCase(area)) {
                    continue;
                }
            }

            String estadoReal = d.getSolicitud().getEstado();
            if (estado != null && !estado.isBlank()) {
                if (estadoReal == null || !estadoReal.equalsIgnoreCase(estado)) {
                    continue;
                }
            }

            String paciente = "";
            if (d.getSolicitud().getPaciente() != null) {
                var p = d.getSolicitud().getPaciente();
                paciente = String.format("%s %s %s",
                        nullSafe(p.getNombre()),
                        nullSafe(p.getPrimerApellido()),
                        nullSafe(p.getSegundoApellido())
                ).trim();
            }

            String nombreExamen = (d.getExamen() != null) ? d.getExamen().getNombre() : "";

            Double monto = d.getSolicitud().getPrecioTotal();

            Reporte dto = new Reporte();
            dto.setFecha(fechaSolicitud.toLocalDate());
            dto.setPaciente(paciente);
            dto.setExamen(nombreExamen);
            dto.setArea(areaNombre);
            dto.setEstado(estadoReal);
            dto.setMonto(monto);

            resultado.add(dto);
        }

        return resultado;
    }

    private String nullSafe(String s) {
        return s == null ? "" : s;
    }
}